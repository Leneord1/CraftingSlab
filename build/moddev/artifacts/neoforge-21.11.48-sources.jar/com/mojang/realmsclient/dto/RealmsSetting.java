package com.mojang.realmsclient.dto;

import com.google.gson.annotations.SerializedName;
import java.util.List;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public record RealmsSetting(@SerializedName("name") String name, @SerializedName("value") String value) implements ReflectionBasedSerialization {
    public static RealmsSetting hardcoreSetting(boolean hardcore) {
        return new RealmsSetting("hardcore", Boolean.toString(hardcore));
    }

    public static boolean isHardcore(List<RealmsSetting> settings) {
        for (RealmsSetting realmssetting : settings) {
            if (realmssetting.name().equals("hardcore")) {
                return Boolean.parseBoolean(realmssetting.value());
            }
        }

        return false;
    }
}
