package com.mojang.blaze3d.vertex;

import it.unimi.dsi.fastutil.ints.IntConsumer;
import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import org.apache.commons.lang3.mutable.MutableLong;
import org.jspecify.annotations.Nullable;
import org.lwjgl.system.MemoryUtil;

@OnlyIn(Dist.CLIENT)
public class MeshData implements AutoCloseable {
    private final ByteBufferBuilder.Result vertexBuffer;
    private ByteBufferBuilder.@Nullable Result indexBuffer;
    private final MeshData.DrawState drawState;

    public MeshData(ByteBufferBuilder.Result vertexBuffer, MeshData.DrawState drawState) {
        this.vertexBuffer = vertexBuffer;
        this.drawState = drawState;
    }

    private static CompactVectorArray unpackQuadCentroids(ByteBuffer buffer, int vertexCount, VertexFormat format) {
        int i = format.getOffset(VertexFormatElement.POSITION);
        if (i == -1) {
            throw new IllegalArgumentException("Cannot identify quad centers with no position element");
        } else {
            FloatBuffer floatbuffer = buffer.asFloatBuffer();
            int j = format.getVertexSize() / 4;
            int k = j * 4;
            int l = vertexCount / 4;
            CompactVectorArray compactvectorarray = new CompactVectorArray(l);

            for (int i1 = 0; i1 < l; i1++) {
                int j1 = i1 * k + i;
                int k1 = j1 + j * 2;
                float f = floatbuffer.get(j1 + 0);
                float f1 = floatbuffer.get(j1 + 1);
                float f2 = floatbuffer.get(j1 + 2);
                float f3 = floatbuffer.get(k1 + 0);
                float f4 = floatbuffer.get(k1 + 1);
                float f5 = floatbuffer.get(k1 + 2);
                float f6 = (f + f3) / 2.0F;
                float f7 = (f1 + f4) / 2.0F;
                float f8 = (f2 + f5) / 2.0F;
                compactvectorarray.set(i1, f6, f7, f8);
            }

            return compactvectorarray;
        }
    }

    public ByteBuffer vertexBuffer() {
        return this.vertexBuffer.byteBuffer();
    }

    public @Nullable ByteBuffer indexBuffer() {
        return this.indexBuffer != null ? this.indexBuffer.byteBuffer() : null;
    }

    public MeshData.DrawState drawState() {
        return this.drawState;
    }

    public MeshData.@Nullable SortState sortQuads(ByteBufferBuilder bufferBuilder, VertexSorting sorting) {
        if (this.drawState.mode() != VertexFormat.Mode.QUADS) {
            return null;
        } else {
            CompactVectorArray compactvectorarray = unpackQuadCentroids(this.vertexBuffer.byteBuffer(), this.drawState.vertexCount(), this.drawState.format());
            MeshData.SortState meshdata$sortstate = new MeshData.SortState(compactvectorarray, this.drawState.indexType());
            this.indexBuffer = meshdata$sortstate.buildSortedIndexBuffer(bufferBuilder, sorting);
            return meshdata$sortstate;
        }
    }

    @Override
    public void close() {
        this.vertexBuffer.close();
        if (this.indexBuffer != null) {
            this.indexBuffer.close();
        }
    }

    @OnlyIn(Dist.CLIENT)
    public record DrawState(VertexFormat format, int vertexCount, int indexCount, VertexFormat.Mode mode, VertexFormat.IndexType indexType) {
    }

    @OnlyIn(Dist.CLIENT)
    public record SortState(CompactVectorArray centroids, VertexFormat.IndexType indexType) {
        public ByteBufferBuilder.@Nullable Result buildSortedIndexBuffer(ByteBufferBuilder bufferBuilder, VertexSorting sorting) {
            int[] aint = sorting.sort(this.centroids);
            long i = bufferBuilder.reserve(aint.length * 6 * this.indexType.bytes);
            IntConsumer intconsumer = this.indexWriter(i, this.indexType);

            for (int j : aint) {
                intconsumer.accept(j * 4 + 0);
                intconsumer.accept(j * 4 + 1);
                intconsumer.accept(j * 4 + 2);
                intconsumer.accept(j * 4 + 2);
                intconsumer.accept(j * 4 + 3);
                intconsumer.accept(j * 4 + 0);
            }

            return bufferBuilder.build();
        }

        private IntConsumer indexWriter(long index, VertexFormat.IndexType type) {
            MutableLong mutablelong = new MutableLong(index);

            return switch (type) {
                case SHORT -> p_350656_ -> MemoryUtil.memPutShort(mutablelong.getAndAdd(2L), (short)p_350656_);
                case INT -> p_350913_ -> MemoryUtil.memPutInt(mutablelong.getAndAdd(4L), p_350913_);
            };
        }
    }
}
